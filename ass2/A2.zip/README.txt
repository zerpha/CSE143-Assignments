Henry Nguyen
Natural Language Processing Ass2
hnguye87

I worked on this assignment alone.

FILES:
  LangProcAss2Part1and2 : this python file was downloaded from google colab 
  where I did the assignment. This file takes in the IMDB set, embeds as 
   a sequence of vectors, transforms it into a single layer RNN/GRU depending
   on what is in comments or not. This can be chosen where you train the data. 
   This file tested Part1 and Part2 of the assignment. 
  

  LangProcAss2Part3 :this python file was downloaded from google colab 
  where I did the assignment. This file uses a pretrained embedding unlike the 
  other file. This file tested part3 of the assignment. 
   

HOW_TO_RUN:
	Both files should be able to run without any special instructions. 